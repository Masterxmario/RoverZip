﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Se ha realizado el ejercicio como un script utilizando a los robots como arrays multidimensionales
            //Cabe destacar que se podría haber creado una clase Robot que tuviera sus tres atributos posicion X, posicion Y y Orientacion pero como no se especificaba nada 
            //se ha decidido realizarlo mediante arrays


            //Constantes
            //Array con dos posiciones de X e Y para definir los límites del rectángulo
            int[] CoordenasXY = new int[2];
            //Array con tres posiciones de X e Y y ORIENTACIÓN del robot introducido
            string[] CoordenasXYZ = new string[3];
            //Array de instrucciones introducidas
            string[] Instrucciones;
            //Lista de array multidimensional para guardar la posicion del robot al salir del mapa
            List<string[,]> Olor = new List<string[,]>();
            //Lista de array multidimensional con todos los datos finales de los robots
            List<string[,]> Output = new List<string[,]>();
            //

            //Funcionalidad
            Console.WriteLine("INPUT(se ha supuesto que para parar de añadir robots es pulsar la tecla intro sin ningun valor por como se muestra en el ejercicio)");
            try
            {
            CoordenasXY = MetodosInput.SolicitarCoordenadasXY();
            while (true)
            {
                
                CoordenasXYZ = MetodosInput.SolicitasCoordenadasXYZ();
                if (CoordenasXYZ[0] == "")
                {
                    break;
                }
                
                Instrucciones = MetodosInput.SolicitarInstrucciones();               
                if (MetodosRobot.ComprobarPosicion(CoordenasXY, CoordenasXYZ) == true)
                {
                    var LOST = false;
                    for (int i = 0; i < Instrucciones.Length; i++)
                    {
                        if (!MetodosRobot.ComprobarRastro(CoordenasXYZ, Olor, Instrucciones[i]))
                        {
                            if (Instrucciones[i] == "L")
                            {
                                    MetodosRobot.Girar("L", CoordenasXYZ);
                            }
                            else if (Instrucciones[i] == "R")
                            {
                                    MetodosRobot.Girar("R", CoordenasXYZ);
                            }
                            else
                            {
                                    MetodosRobot.Avanzar(CoordenasXYZ);
                                if (MetodosRobot.ComprobarPosicion(CoordenasXY, CoordenasXYZ) == false)
                                {
                                    LOST = true;
                                    MetodosRobot.AñadirRastro(CoordenasXYZ, Olor);
                                    i = Instrucciones.Length;
                                }
                            }
                        }
                        else
                        {
                            //Log se ha saltado la instruccion correctamente
                        }
                    }
                    MetodosOutput.OUTPUT(Output, CoordenasXYZ, LOST);
                        //Log se ha cargado la ultima posicion del robot
                    }
                    else
                {
                        //Log se han introducido unas coordenadas fuera del espacio
                }
            }
            }
            catch (Exception e)
            {
                //Log se ha producido el error e
                throw;
            }
            Console.WriteLine("OUTPUT");
            foreach (var item in Output)
            {
                Console.WriteLine(item[0, 0] + " " + item[0, 1] + " " + item[0, 2] + " " + item[0, 3]);

            }
            //Se añade esto para que en la ejecución del script te vuelva a pedir un dato y así se pueda observar el resultado correcto.
            string cadenapositions2;
            cadenapositions2 = Console.ReadLine();
        }
    }
 }

